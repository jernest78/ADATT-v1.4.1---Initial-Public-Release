===============================================================================
ADATT v1.6.0 - Automated Directory & Azure Termination Tool
Professional Employee Offboarding Automation
===============================================================================

WHAT'S INCLUDED
---------------
✓ ADATT-UX.ps1                 - Main application (PowerShell)
✓ START_HERE_v1.6.0.pdf        - Quick start guide
✓ QUICK_REFERENCE_v1.6.0.pdf   - Features & shortcuts reference
✓ BulkTemplate.csv             - Sample bulk termination template
✓ test-prerequisites.ps1       - System readiness checker
✓ LICENSE.txt                  - Software license agreement

QUICK START
-----------
1. Check Prerequisites
   Run: .\test-prerequisites.ps1
   
2. Launch ADATT
   Run: .\ADATT-UX.ps1
   
3. Activate License
   Click "Activate License" button
   Enter your key from LemonSqueezy
   
4. Start Offboarding
   - Single User: Enter username → Click "Terminate"
   - Bulk: Load CSV → Preview → Click "Bulk Offboard"
   - Reset MFA: Enter username → Click "Reset MFA"

SYSTEM REQUIREMENTS
-------------------
✓ Windows Server 2016+ or Windows 10/11
✓ PowerShell 5.1 or later
✓ Active Directory (for hybrid/on-prem users)
✓ Microsoft Graph PowerShell SDK
✓ Exchange Online Management module

PERMISSIONS REQUIRED
--------------------
✓ Domain Admin or delegated AD rights
✓ Exchange Administrator role
✓ User Administrator (Microsoft Graph)
✓ Groups Administrator (Microsoft Graph)

NEW IN v1.6.0
-------------
✨ Operation History - Complete audit trail (Ctrl+H)
✨ Email Reports - Send history to IT Admin/HR
✨ Print Reports - Professional formatted reports
✨ Connection Monitoring - Real-time AD/Exchange/Graph status
✨ Settings Panel - Centralized configuration (Ctrl+,)
✨ User Autocomplete - Smart username suggestions
✨ Enhanced Errors - Detailed error messages with copy
✨ Memory Stability - Fixed minimize/maximize crashes

KEYBOARD SHORTCUTS
------------------
F1       - Show Help
ESC      - Close dialog/exit
Ctrl+T   - Focus Terminate field
Ctrl+M   - Reset MFA
Ctrl+D   - Remove Devices
Ctrl+S   - Sign Out Sessions
Ctrl+F   - Choose Bulk File
Ctrl+B   - Bulk Offboard
Ctrl+H   - View Operation History
Ctrl+,   - Open Settings

SUPPORT & DOCUMENTATION
-----------------------
📖 START_HERE_v1.6.0.pdf      - Complete getting started guide
📖 QUICK_REFERENCE_v1.6.0.pdf - Daily reference card
📧 Email: adatt@unifosec.com
🌐 Website: https://adatt.lemonsqueezy.com

LICENSE INFORMATION
-------------------
Trial: 14 days, all features unlocked

Licenses (20% LAUNCH20 discount available):
- Solo Admin (1 device):    
- Team (5 devices):         
- Business (20 devices):   

Purchase at: https://adatt.lemonsqueezy.com

INSTALLATION
------------
Option 1: Portable (Recommended for Testing)
   1. Extract all files to folder (e.g., C:\Tools\ADATT)
   2. Right-click ADATT-UX.ps1 → Run with PowerShell

Option 2: System Installation
   1. Copy files to: C:\Program Files\ADATT\
   2. Create desktop shortcut to ADATT-UX.ps1
   3. Set execution policy if needed:
      Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned

FIRST-TIME SETUP
----------------
1. ✓ Run test-prerequisites.ps1 to verify system
2. ✓ Configure IT Admin email in Settings (Ctrl+,)
3. ✓ Enable email notifications (optional)
4. ✓ Test with single user before bulk operations

TROUBLESHOOTING
---------------
Issue: "Script execution is disabled"
Fix: Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned

Issue: "Module not found"
Fix: ADATT will prompt to install required modules automatically

Issue: Connection errors
Fix: Check status indicators in footer (bottom-right)
     Use Settings (Ctrl+,) to verify configuration

Issue: License activation fails
Fix: Check internet connection
     Verify license key from email
     Contact adatt@unifosec.com

FEATURES AT A GLANCE
--------------------
✓ Single User Termination - Disable AD, revoke sessions, hide from GAL
✓ Bulk Offboarding - Process 2-100 users with preview
✓ MFA Reset - Clear authentication methods
✓ Device Removal - Wipe registered devices (with confirmation)
✓ Sign Out Sessions - Force logout from all services
✓ Operation History - Audit trail with operator tracking
✓ Email Reports - Automatic notifications to IT Admin/HR
✓ Print Reports - Physical documentation for compliance
✓ Connection Monitoring - Real-time service status
✓ Hybrid Support - Cloud-only, Hybrid, On-premises users

SECURITY & COMPLIANCE
---------------------
✓ Complete audit trail with timestamps
✓ Operator tracking (captures username)
✓ Email notifications for management
✓ CSV reports for compliance documentation
✓ Operation history (50 visible, 100 stored)
✓ Encrypted configuration storage

VERSION HISTORY
---------------
v1.6.0 (January 2026) - Current
   - Operation history with email/print
   - Dynamic connection monitoring
   - Settings panel
   - Memory leak fixes
   
v1.5.0 (January 2026)
   - Cloud-only Entra ID support
   - Batch optimization
   - Account type tracking
   
v1.4.1 (December 2025)
   - LemonSqueezy licensing
   - Trial mode
   - Email notifications

===============================================================================
Version: 1.6.0
Release Date: January 2026
Author: Jose Ernest
Company: Unifosec

© 2025-2026 Jose Ernest / Unifosec. All rights reserved.
===============================================================================
