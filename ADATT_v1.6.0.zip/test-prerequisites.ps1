# Test Prerequisites Checker
# This script tests the prerequisite checking without running the full ADATT

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Testing ADATT Prerequisite Checker" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

Write-Host "Checking prerequisites..." -ForegroundColor Yellow

$missing = @()
$warnings = @()

# 1. Check PowerShell Execution Policy
$executionPolicy = Get-ExecutionPolicy -Scope CurrentUser
if ($executionPolicy -eq 'Restricted' -or $executionPolicy -eq 'Undefined') {
    $missing += "PowerShell Execution Policy needs to be set to RemoteSigned or Unrestricted"
}

# 2. Check for RSAT-AD-PowerShell module
$adModule = Get-Module -ListAvailable -Name ActiveDirectory -ErrorAction SilentlyContinue
if (-not $adModule) {
    $missing += "Active Directory PowerShell Module (RSAT) is not installed"
}

# 3. Check PowerShell version
if ($PSVersionTable.PSVersion.Major -lt 5) {
    $missing += "PowerShell 5.1 or later is required (Current: $($PSVersionTable.PSVersion))"
}

# 4. Check if running as Administrator
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    $warnings += "ADATT is not running as Administrator. Some features may not work correctly."
}

Write-Host ""
Write-Host "Check Results:" -ForegroundColor Cyan

Write-Host "  Execution Policy: " -NoNewline
if ($executionPolicy -in @('RemoteSigned','Unrestricted','Bypass')) {
    Write-Host "OK ($executionPolicy)" -ForegroundColor Green
} else {
    Write-Host "FAIL ($executionPolicy)" -ForegroundColor Red
}

Write-Host "  AD Module: " -NoNewline
if ($adModule) {
    Write-Host "Installed" -ForegroundColor Green
} else {
    Write-Host "Missing" -ForegroundColor Red
}

Write-Host "  PowerShell: " -NoNewline
if ($PSVersionTable.PSVersion.Major -ge 5) {
    Write-Host "OK ($($PSVersionTable.PSVersion))" -ForegroundColor Green
} else {
    Write-Host "Old version" -ForegroundColor Red
}

Write-Host "  Admin Rights: " -NoNewline
if ($isAdmin) {
    Write-Host "Yes" -ForegroundColor Green
} else {
    Write-Host "No (warning only)" -ForegroundColor Yellow
}

Write-Host ""

if ($missing.Count -gt 0) {
    Write-Host "WOULD SHOW MESSAGE BOX WITH:" -ForegroundColor Yellow
    foreach ($item in $missing) {
        Write-Host "  - $item" -ForegroundColor Red
    }
    Write-Host ""
    Write-Host "ADATT would not start until these are fixed." -ForegroundColor Red
} elseif ($warnings.Count -gt 0) {
    Write-Host "Warnings:" -ForegroundColor Yellow
    foreach ($warning in $warnings) {
        Write-Host "  - $warning" -ForegroundColor Yellow
    }
    Write-Host ""
    Write-Host "ADATT would start with warnings." -ForegroundColor Yellow
} else {
    Write-Host "All prerequisites met! ADATT would start normally." -ForegroundColor Green
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Test Complete" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
